# Test Scenarios for Document Analysis Pipeline

## Exercise 4-1 Testing Guide

### Test 1: Good Proposal (sample_proposal_good.md)

**Expected Results:**
- Overall Score: 85-95
- Section Scores:
  - Executive Summary: 90+ (clear, concise, all elements)
  - Problem Analysis: 90+ (quantified data, stakeholders, root cause)
  - Proposed Solution: 85+ (technology, scope, timeline, resources)
  - Expected Outcomes: 90+ (specific KPIs, measurement, risks)
  - Budget & Resources: 85+ (itemized, ROI calculated)
- Strengths identified:
  - Quantified problem (3 hours, 45 staff, 15,000 hours)
  - Specific KPIs (80% reduction, 36 minutes target)
  - Clear timeline with phases
  - ROI calculation included
- Minor improvements:
  - Could add more detail on change management
  - Consider adding success criteria for each phase

### Test 2: Poor Proposal (sample_proposal_poor.md)

**Expected Results:**
- Overall Score: 30-50
- Section Scores:
  - Executive Summary: 40 (vague, no specifics)
  - Problem Analysis: 20 (no data, no stakeholders)
  - Proposed Solution: 30 (vague technology, no timeline)
  - Expected Outcomes: 20 (no KPIs, no measurement)
  - Budget & Resources: 10 (no budget mentioned)
- Missing Elements:
  - Quantified problem statement
  - Specific solution approach
  - Timeline with milestones
  - Budget breakdown
  - Measurable KPIs
  - Risk analysis
- Improvement Suggestions:
  - Add specific data on current time spent
  - Define measurable success criteria
  - Create detailed timeline
  - Provide budget estimate
  - Identify affected stakeholders

### Test 3: Custom Proposal

**Instructions:**
1. Write your own project proposal
2. Include some strong sections and some weak sections
3. Run through the workflow
4. Compare analysis results with your self-assessment

**Suggested Topics:**
- Customer feedback analysis automation
- Employee onboarding process digitization
- Inventory management system upgrade
- Meeting scheduling optimization

### Verification Checklist

After running each test:

- [ ] Doc Extractor successfully parsed the document
- [ ] LLM extracted fields match document content
- [ ] Knowledge Base returned relevant guidelines
- [ ] Analysis scores are reasonable and justified
- [ ] Missing elements are correctly identified
- [ ] Improvement suggestions are actionable
- [ ] Output template is properly formatted
