# Scoring Weights and Calculation Guide

## Exercise 4-2: Parallel Processing & Aggregation

### Understanding the Weighted Score

The multi-criteria evaluation uses weighted scoring to combine four dimensions into a single decision score.

## Weight Distribution

| Dimension | Weight | Rationale |
|-----------|--------|-----------|
| Completeness | 30% | Most critical - incomplete proposals cannot be evaluated properly |
| Feasibility | 25% | Essential - unrealistic proposals waste resources |
| Impact | 25% | Important - must deliver business value |
| Quality | 20% | Supporting - good presentation aids understanding |

## Calculation Formula

```python
weighted_score = (completeness * 0.30) + (feasibility * 0.25) + (impact * 0.25) + (quality * 0.20)
```

## Decision Thresholds

| Score | Decision | Meaning |
|-------|----------|---------|
| 80-100 | APPROVE | Ready for implementation |
| 60-79 | REVIEW | Good but needs minor clarification |
| 40-59 | REVISE | Significant gaps, return for improvement |
| 0-39 | REJECT | Does not meet minimum standards |

## Code Node Implementation

```python
import json

def main(completeness_score: str, feasibility_score: str, impact_score: str, quality_score: str) -> dict:
    # Parse JSON scores from each parallel branch
    try:
        c = json.loads(completeness_score)["score"]
        f = json.loads(feasibility_score)["score"]
        i = json.loads(impact_score)["score"]
        q = json.loads(quality_score)["score"]
    except:
        # Default to 0 if parsing fails
        c = f = i = q = 0

    # Calculate weighted score
    weighted = (c * 0.30) + (f * 0.25) + (i * 0.25) + (q * 0.20)

    # Determine decision based on thresholds
    if weighted >= 80:
        decision = "APPROVE"
    elif weighted >= 60:
        decision = "REVIEW"
    elif weighted >= 40:
        decision = "REVISE"
    else:
        decision = "REJECT"

    return {
        "completeness": c,
        "feasibility": f,
        "impact": i,
        "quality": q,
        "weighted_score": round(weighted, 1),
        "decision": decision
    }
```

## Variable Aggregator Configuration

The Variable Aggregator node combines outputs from all parallel branches:

**Input Variables:**
- `completeness_score` - from Completeness LLM branch
- `feasibility_score` - from Feasibility LLM branch
- `impact_score` - from Impact LLM branch
- `quality_score` - from Quality LLM branch

**Output Format:** Object (to pass to Code node)

## Testing the Calculation

### Test Case 1: Strong Submission
- Completeness: 90 → 90 × 0.30 = 27.0
- Feasibility: 85 → 85 × 0.25 = 21.25
- Impact: 80 → 80 × 0.25 = 20.0
- Quality: 75 → 75 × 0.20 = 15.0
- **Total: 83.25 → APPROVE**

### Test Case 2: Medium Submission
- Completeness: 70 → 70 × 0.30 = 21.0
- Feasibility: 65 → 65 × 0.25 = 16.25
- Impact: 60 → 60 × 0.25 = 15.0
- Quality: 70 → 70 × 0.20 = 14.0
- **Total: 66.25 → REVIEW**

### Test Case 3: Weak Submission
- Completeness: 40 → 40 × 0.30 = 12.0
- Feasibility: 50 → 50 × 0.25 = 12.5
- Impact: 45 → 45 × 0.25 = 11.25
- Quality: 55 → 55 × 0.20 = 11.0
- **Total: 46.75 → REVISE**

### Test Case 4: Poor Submission
- Completeness: 20 → 20 × 0.30 = 6.0
- Feasibility: 30 → 30 × 0.25 = 7.5
- Impact: 25 → 25 × 0.25 = 6.25
- Quality: 30 → 30 × 0.20 = 6.0
- **Total: 25.75 → REJECT**
