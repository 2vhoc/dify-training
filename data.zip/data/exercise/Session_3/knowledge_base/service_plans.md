# Service Plan Catalog

## FLET'S Hikari Next
### Family Super High-Speed Type (Hayabusa)
- Max Speed: Approx. 1Gbps upload/download
- Monthly Fee: 5,940 JPY (tax included)
- Initial Cost: Installation fee 19,800 JPY
- Target: Detached houses

### Mansion Super High-Speed Type (Hayabusa)
- Max Speed: Approx. 1Gbps upload/download
- Monthly Fee: 3,575-4,785 JPY (tax included) *varies by building type
- Initial Cost: Installation fee 16,500 JPY
- Target: Apartment buildings

## Hikari Denwa (Optical Phone)
### Basic Plan
- Monthly Base Fee: 550 JPY (tax included)
- Call Rate: Nationwide flat rate 8.8 JPY/3 min
- Emergency Call Support: 110/119 supported

### Hikari Denwa Office Type
- Monthly Base Fee: 1,430 JPY (tax included)
- Channels: Up to 8 channels
- Numbers: Up to 32 numbers

## FLET'S VPN
### Wide
- Inter-office VPN connection service
- Monthly Fee: Varies by number of sites and bandwidth
- Security: IPsec supported
