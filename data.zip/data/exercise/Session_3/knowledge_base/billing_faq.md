# Billing & Payment FAQ

## Q: When will my bill arrive?
A: Bills are mailed around the 10th of each month. If you use Web billing, you will be notified by email around the 5th.

## Q: How do I change my payment method?
A: You can choose from credit card, bank transfer, or invoice payment. Changes can be made through the customer portal or by calling 0120-116-116.

## Q: Why is my bill higher than last month?
A: The following reasons are possible:
1. Addition of optional services
2. Increased call charges (if using Hikari Denwa)
3. End of campaign discount period
4. Start of installment payments for installation fees
Please check your Web billing statement or call for details.

## Q: When is my payment due date?
A: For bank transfer, it is the 25th of each month. For credit card, it follows your card company's billing cycle.

## Q: How do I view my bill online?
A: Log in to the customer portal at https://billing.example.com with your customer ID and password. Bills are available for the past 12 months.

## Q: Can I get a receipt for my payment?
A: Yes. You can download a receipt from the customer portal after payment is confirmed. For credit card payments, your credit card statement also serves as a receipt.

## Q: What happens if I miss a payment?
A: A reminder notice will be sent within 10 days. If payment is not received within 30 days of the due date, service may be temporarily suspended. Please contact us immediately if you have difficulty making a payment.
