# Technical Troubleshooting Guide

## When You Cannot Connect to the Internet

### Step 1: Check Equipment
- Check ONU (Optical Network Unit) indicator lights
  - Authentication light: Green (steady) = Normal
  - Authentication light: Off/Red = Possible line failure
- Check router power light
  - Green (steady) = Normal
  - Red (blinking) = Restart required

### Step 2: Restart Equipment
1. Turn off the router power
2. Turn off the ONU power
3. Wait 30 seconds
4. Turn on the ONU power (wait 2 minutes)
5. Turn on the router power (wait 2 minutes)
6. Check the connection

### Step 3: If Still Not Resolved
- Fault Reporting: 0120-000-113 (24-hour service)
- Web Fault Report: https://flets.com/trouble/

## When Internet Speed is Slow

### Items to Check
1. Measure current speed using a speed test site
2. Compare speeds between wired and wireless connections
3. Check for speed variations by time of day
4. Check number of connected devices (too many causes slowdown)

### Improvement Methods
- Restart the router
- Change Wi-Fi channel
- Replace LAN cable (Cat6 or higher recommended)
- Switch to IPv6 (IPoE) connection

## Wi-Fi Connection Issues

### Cannot Find Network Name (SSID)
1. Check if the router is powered on
2. Verify SSID broadcast is enabled in router settings
3. Try moving closer to the router
4. Check if 2.4GHz or 5GHz band is selected on your device

### Connected but No Internet
1. Check if other devices can connect
2. Forget the network and reconnect
3. Check IP address settings (should be automatic/DHCP)
4. Try connecting with a wired connection to isolate the issue

## VoIP Phone Issues

### No Dial Tone
1. Check phone cable connection to VoIP adapter
2. Verify VoIP adapter power light is on
3. Check if internet connection is working
4. Restart the VoIP adapter

### Call Quality Issues
1. Check internet speed (minimum 1Mbps recommended for VoIP)
2. Enable QoS settings on router for voice traffic
3. Reduce number of simultaneous internet activities during calls
4. Check for packet loss using network diagnostic tools
