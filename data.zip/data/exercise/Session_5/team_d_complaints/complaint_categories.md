# Complaint Category Definitions

## Category Overview

| Category | Code | Priority Range | Typical SLA |
|----------|------|----------------|-------------|
| Service Outage | SO | Critical-High | 4-24 hours |
| Billing Issues | BI | Medium-High | 48-72 hours |
| Appointment Issues | AI | High-Medium | Same day |
| Equipment Issues | EI | High-Medium | 24-48 hours |
| Service Quality | SQ | Medium-High | 48 hours |
| Staff Conduct | SC | High | 24 hours |

---

## Service Outage (SO)

### Definition
Complete or significant loss of service affecting the customer's ability to use telecommunications services.

### Sub-Categories
- **SO-01:** Complete internet outage
- **SO-02:** Intermittent connectivity
- **SO-03:** VoIP service down
- **SO-04:** Multiple service outage

### Priority Determination
- **Critical:** Complete outage affecting business operations
- **High:** Partial outage or residential complete outage
- **Medium:** Intermittent issues, workaround available

### SLA
- **Response Time:** Within 15 minutes (Critical), 1 hour (High)
- **Resolution Target:** Within 4 hours (Critical), 24 hours (High)
- **Escalation:** To NOC Manager if >6 hours unresolved

### Common Root Causes
- Equipment failure
- Fiber cut
- Power outage at exchange
- Configuration error
- Network congestion

---

## Billing Issues (BI)

### Definition
Complaints related to incorrect charges, billing disputes, payment problems, or pricing confusion.

### Sub-Categories
- **BI-01:** Incorrect charges
- **BI-02:** Double billing
- **BI-03:** Bill not received
- **BI-04:** Payment not reflected
- **BI-05:** Pricing dispute

### Priority Determination
- **High:** Repeated errors (3+ months), large amounts (>10,000 JPY)
- **Medium:** First-time error, moderate amounts
- **Low:** General inquiry about charges

### SLA
- **Response Time:** Within 48 hours
- **Resolution Target:** Within 72 hours
- **Escalation:** To Finance if >72 hours unresolved

### Common Root Causes
- System billing errors
- Plan change not applied
- Promotion expiration
- Payment processing delay
- Miscommunication about pricing

---

## Appointment Issues (AI)

### Definition
Complaints about missed appointments, scheduling problems, or technician visit issues.

### Sub-Categories
- **AI-01:** Missed appointment (no show)
- **AI-02:** Late arrival (>30 minutes)
- **AI-03:** Rescheduling without notice
- **AI-04:** Unable to schedule convenient time
- **AI-05:** Technician left without completing work

### Priority Determination
- **High:** Same-day issues, missed multiple times
- **Medium:** Future appointment problems
- **Low:** General scheduling inquiries

### SLA
- **Response Time:** Same-day for missed appointments
- **Resolution Target:** Reschedule within 24 hours
- **Escalation:** To Field Ops Manager if repeated

### Common Root Causes
- Dispatch system errors
- Traffic/weather delays
- Overbooking
- Incorrect customer information
- Parts unavailability

---

## Equipment Issues (EI)

### Definition
Complaints about equipment failures, replacement needs, or equipment-related problems.

### Sub-Categories
- **EI-01:** Equipment malfunction
- **EI-02:** Equipment replacement needed
- **EI-03:** Equipment compatibility issues
- **EI-04:** Equipment delivery delay
- **EI-05:** Equipment setup problems

### Priority Determination
- **High:** Critical equipment (ONU, main router) failure
- **Medium:** Secondary equipment issues
- **Low:** Equipment upgrade requests

### SLA
- **Response Time:** Within 4 hours (High), 24 hours (Medium)
- **Resolution Target:** Next-day replacement for critical equipment
- **Escalation:** To Supply Chain if inventory issues

### Common Root Causes
- Equipment age/wear
- Power surge damage
- Software/firmware bugs
- Environmental factors (heat, humidity)
- User error

---

## Service Quality (SQ)

### Definition
Complaints about speed issues, reliability concerns, or service not meeting expectations.

### Sub-Categories
- **SQ-01:** Slow internet speed
- **SQ-02:** Call quality issues
- **SQ-03:** Wi-Fi coverage problems
- **SQ-04:** Service not as advertised
- **SQ-05:** Frequent disconnections

### Priority Determination
- **High:** Business customers, severe degradation
- **Medium:** General quality issues
- **Low:** Minor inconveniences

### SLA
- **Response Time:** Within 24 hours
- **Resolution Target:** Technical assessment within 48 hours
- **Escalation:** To Technical Manager if systemic

### Common Root Causes
- Network congestion
- Equipment limitations
- Building interference
- Distance from exchange
- External interference

---

## Staff Conduct (SC)

### Definition
Complaints about employee behavior, rudeness, or unprofessional conduct.

### Sub-Categories
- **SC-01:** Rude or dismissive behavior
- **SC-02:** Unprofessional language
- **SC-03:** Incorrect information provided
- **SC-04:** Privacy violation
- **SC-05:** Discrimination or harassment

### Priority Determination
- **Critical:** Privacy violation, harassment
- **High:** All other conduct issues

### SLA
- **Response Time:** HR review within 24 hours
- **Resolution Target:** Customer callback within 48 hours
- **Escalation:** To HR immediately for all cases

### Response Guidelines
- Apologize sincerely
- Do not defend the employee
- Assure the customer of investigation
- Follow up with concrete actions taken

---

## Cross-Category Issues

### Multiple Category Complaints
When a complaint spans multiple categories:
1. Identify the primary complaint
2. Assign to highest priority category
3. Note secondary issues for tracking
4. Ensure all issues are addressed in resolution

### Escalation Matrix
| Category | First Escalation | Second Escalation |
|----------|------------------|-------------------|
| Service Outage | NOC Manager | Area Director |
| Billing | Finance Manager | CFO |
| Appointment | Field Ops Manager | Operations Director |
| Equipment | Supply Chain Manager | Operations Director |
| Service Quality | Technical Manager | CTO |
| Staff Conduct | HR Manager | HR Director |
