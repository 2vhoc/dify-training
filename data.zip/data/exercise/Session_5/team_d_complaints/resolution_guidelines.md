# Complaint Resolution Guidelines

## Emotion-Based Response Strategies

### Very Angry / Angry

**Indicators:**
- Raised voice, aggressive language
- Demands to speak to manager
- Threats to cancel or post negative reviews
- Multiple exclamation points in written communication

**Response Strategy:**
1. **Acknowledge immediately** - "I understand this is extremely frustrating"
2. **Apologize sincerely** - "I'm truly sorry for this experience"
3. **Take ownership** - "Let me personally handle this for you"
4. **Provide concrete action and timeline** - "Here's exactly what I'm going to do..."
5. **Offer compensation consideration** - Proactively mention credit or compensation
6. **Manager follow-up within 24 hours** - Promise and deliver callback

**Sample Response:**
"I'm truly sorry you've had to deal with this. This is not the level of service we want to provide. I'm going to personally ensure this is resolved today. Here's what I'm doing right now: [specific actions]. I'll call you back by [time] with an update, and my manager will follow up tomorrow to make sure you're completely satisfied."

---

### Frustrated

**Indicators:**
- Exasperated tone
- Mentions repeated issues
- "I've already called about this"
- Sighing, impatience

**Response Strategy:**
1. **Validate their experience** - "I can see why this is so frustrating"
2. **Acknowledge history** - "I see you've contacted us before about this"
3. **Explain what went wrong** - Be transparent about the issue
4. **Provide clear resolution path** - Step-by-step what happens next
5. **Offer expedited service** - "I'm flagging this as priority"

**Sample Response:**
"I completely understand your frustration - dealing with the same issue multiple times is not acceptable. I can see from your history that this started on [date]. Let me explain what happened and what we're doing differently this time to make sure it's fixed permanently."

---

### Disappointed

**Indicators:**
- Quiet, resigned tone
- "I expected better"
- Mentions loyalty or tenure as customer
- May compare to competitors

**Response Strategy:**
1. **Express understanding** - "We value your loyalty and this isn't how we want to treat you"
2. **Acknowledge the gap** - Between expectation and reality
3. **Provide solution options** - Give choices when possible
4. **Request feedback** - "What would make this right for you?"
5. **Thank them for patience** - Recognize their continued relationship

**Sample Response:**
"Thank you for sharing this with us. As a customer for [X years], you deserve much better. I understand we haven't met your expectations, and I want to make this right. Here are the options I can offer..."

---

### Neutral / Calm

**Indicators:**
- Matter-of-fact tone
- Seeking information
- Not emotionally charged
- Simple question or request

**Response Strategy:**
1. **Thank for bringing to attention** - "Thank you for letting us know"
2. **Provide information clearly** - Direct and concise
3. **Confirm satisfaction** - "Does this answer your question?"
4. **Offer additional assistance** - "Is there anything else I can help with?"

**Sample Response:**
"Thank you for contacting us about this. Here's the information you need: [answer]. Please let me know if you need any clarification or have other questions."

---

## Compensation Guidelines

### Service Credits

| Situation | Credit Amount |
|-----------|---------------|
| Outage 4-24 hours | 1 day service credit |
| Outage 24-72 hours | 1 week service credit |
| Outage >72 hours | 2 weeks + escalation |
| Repeated issues (3+ in 3 months) | 1 month service credit |
| Missed appointment (first time) | 3 days service credit |
| Missed appointment (repeat) | 1 week + priority scheduling |

### Additional Compensation Options

| Situation | Compensation |
|-----------|--------------|
| Billing error | Full correction + 500 JPY credit |
| Repeated billing errors | 1 month credit + escalation |
| Equipment delay >1 week | 1 week credit + expedited shipping |
| Poor staff conduct | Apology letter + service upgrade offer |
| Business revenue loss | Case-by-case review (up to 1 month credit) |

### Compensation Authority Levels

| Amount | Authority |
|--------|-----------|
| Up to 1 week credit | Front-line representative |
| Up to 1 month credit | Team leader |
| Up to 3 months credit | Manager |
| >3 months or special cases | Director approval required |

---

## Resolution Procedures by Category

### Service Outage Resolution

1. **Verify outage scope** - Check if area-wide or customer-specific
2. **Check known issues** - Review NOC alerts and maintenance schedules
3. **Remote diagnostics** - Test line and equipment remotely
4. **Dispatch if needed** - Schedule technician visit
5. **Provide updates** - Proactive communication until resolved
6. **Post-resolution follow-up** - Confirm service restored, offer credit

### Billing Resolution

1. **Review account history** - Check for recent changes
2. **Identify discrepancy** - Compare expected vs. actual charges
3. **Determine cause** - System error, plan change, etc.
4. **Process correction** - Adjust charges as needed
5. **Confirm with customer** - Explain what was corrected
6. **Document for prevention** - Flag systemic issues

### Appointment Resolution

1. **Acknowledge and apologize** - Immediately
2. **Identify cause** - Why was appointment missed/delayed
3. **Reschedule priority** - Next available slot, customer preference
4. **Offer compensation** - Service credit for inconvenience
5. **Document incident** - For dispatch team improvement

---

## Escalation Triggers

### Immediate Escalation Required

- Customer mentions legal action
- Customer mentions media/social media exposure
- Safety concerns
- Privacy breach suspected
- VIP/corporate customer
- Third complaint about same issue

### Manager Callback Required

- Any "Very Angry" customer
- Compensation request exceeds authority
- Customer specifically requests manager
- Complex multi-issue complaint
- Any Staff Conduct complaint

---

## Documentation Requirements

### All Complaints

- Customer ID and contact information
- Date and time of complaint
- Category and sub-category
- Emotion level assessment
- Detailed description of issue
- Actions taken
- Resolution and compensation offered
- Follow-up commitments

### Escalated Complaints

- All above plus:
- Escalation reason
- Manager/director involved
- Timeline of all communications
- Final resolution approval
- Customer satisfaction confirmation
