# Past Proposal Archive

## Proposal 1: Yamagata Prefecture Office Network (2024)

### Project Overview
- **Client:** Yamagata Prefectural Government
- **Scope:** 8 facilities, full network replacement
- **Contract Value:** 65 million JPY
- **Duration:** 8 months
- **Result:** WON

### Proposal Highlights
- Emphasized local presence with Sendai-based support team
- Proposed phased implementation to minimize disruption
- Included comprehensive training program for prefecture IT staff
- Offered 24/7 support with 2-hour response guarantee

### Key Success Factors
1. Strong local presence emphasized throughout proposal
2. Competitive pricing with phased implementation option
3. 24/7 support center in Sendai highlighted
4. Excellent reference from Miyagi Prefecture
5. Detailed risk mitigation plan

### Lessons Learned
- Prefectural clients value local relationships highly
- Government clients appreciate detailed documentation
- Training and knowledge transfer are differentiators
- Price is important but not the only factor

---

## Proposal 2: Fukushima Hospital Network (2024)

### Project Overview
- **Client:** Fukushima Medical University
- **Scope:** Medical-grade network with strict security requirements
- **Contract Value:** 120 million JPY
- **Duration:** 12 months
- **Result:** WON

### Proposal Highlights
- Emphasized healthcare compliance expertise
- Proposed redundant architecture with 99.99% uptime SLA
- Included HIPAA-equivalent security measures
- Dedicated medical IT specialist on project team

### Key Success Factors
1. Healthcare compliance expertise clearly demonstrated
2. Reference from Iwate Medical Center was crucial
3. Security certifications highlighted prominently
4. Proposed dedicated support team for healthcare
5. Detailed disaster recovery plan

### Lessons Learned
- Medical clients need strong compliance assurance
- Security is non-negotiable in healthcare
- References from similar institutions carry heavy weight
- Higher price accepted for specialized expertise

---

## Proposal 3: Morioka City Office Upgrade (2023)

### Project Overview
- **Client:** Morioka City
- **Scope:** 12 facilities, network modernization
- **Contract Value:** 55 million JPY (proposal)
- **Duration:** 10 months
- **Result:** LOST to competitor

### Proposal Analysis
- Our proposal was technically strong
- Competitor offered 15% lower price
- Our Wi-Fi 6 approach was seen as over-engineered
- Limited emphasis on cost optimization

### Loss Factors
1. Price 15% higher than winning competitor
2. Less emphasis on innovation in proposal
3. Weak response to Wi-Fi 6 requirements
4. Competitor had recent Morioka project reference
5. Our timeline was 2 months longer

### Lessons Learned
- Municipal clients are often price-sensitive
- Need to balance innovation with practical value
- Local references matter significantly
- Timeline competitiveness is important
- Should have offered tiered pricing options

---

## Proposal 4: Akita Bank Network Security (2023)

### Project Overview
- **Client:** Regional Bank (Akita)
- **Scope:** Security-focused network upgrade
- **Contract Value:** 90 million JPY
- **Duration:** 14 months
- **Result:** WON

### Proposal Highlights
- Zero-trust architecture proposal
- FISC compliance expertise demonstrated
- 24/7 Security Operations Center integration
- Incident response capabilities highlighted

### Key Success Factors
1. FISC compliance expertise was decisive
2. Zero-trust architecture proposal innovative
3. Strong incident response capabilities
4. Dedicated financial sector team
5. Excellent security audit track record

### Lessons Learned
- Financial clients prioritize security above all
- Compliance certifications are table stakes
- Innovation in security approach valued
- Long-term relationship potential important
- Premium pricing acceptable for security expertise

---

## Proposal 5: Aomori Prefecture Education Network (2023)

### Project Overview
- **Client:** Aomori Prefecture Board of Education
- **Scope:** 50 schools, network standardization
- **Contract Value:** 180 million JPY
- **Duration:** 18 months
- **Result:** WON

### Proposal Highlights
- Scalable design for future expansion
- Student safety features (content filtering)
- Teacher training program included
- Remote support capabilities for rural schools

### Key Success Factors
1. Education sector experience demonstrated
2. Content filtering and safety features
3. Comprehensive training program
4. Cost-effective solution for large scale
5. Strong project management approach

### Lessons Learned
- Education clients value safety features
- Training and support are differentiators
- Scale requires careful project management
- Rural connectivity challenges need addressing
- Long-term relationship building important

---

## Summary: Win/Loss Analysis

### Overall Record
- Won: 4 projects
- Lost: 1 project
- Win Rate: 80%

### Common Success Factors
1. Relevant industry/sector experience
2. Strong local presence and support
3. Compliance and security expertise
4. Comprehensive training programs
5. Detailed documentation and planning

### Areas for Improvement
1. Price competitiveness for municipal clients
2. Shorter implementation timelines
3. More tiered pricing options
4. Stronger innovation messaging
5. More proactive relationship building
