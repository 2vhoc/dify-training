# Request for Proposal
## Municipal Network Infrastructure Upgrade

**RFP Number:** CITY-2025-NET-001
**Issue Date:** January 15, 2025
**Closing Date:** February 28, 2025, 17:00 JST

---

## 1. Project Overview

Sendai City seeks proposals for upgrading the network infrastructure across 15 municipal facilities including city hall, branch offices, and community centers.

### 1.1 Background
The current network infrastructure was installed in 2015 and is approaching end of life. The city requires a modern, secure, and high-performance network to support digital government initiatives and improved citizen services.

### 1.2 Objectives
- Replace aging network equipment with modern, high-speed infrastructure
- Implement robust security measures compliant with government standards
- Enable future scalability for smart city initiatives
- Improve network reliability and reduce maintenance costs

---

## 2. Requirements

### 2.1 Technical Requirements

#### Network Performance
- Minimum 1Gbps backbone connectivity between all sites
- 10Gbps uplink capability at main city hall
- Support for 500+ concurrent users per facility
- Latency < 10ms between sites

#### Wireless Infrastructure
- 802.11ax (Wi-Fi 6) access points
- Seamless roaming between access points
- Guest network capability with captive portal
- Coverage: 100% of office and public areas

#### Reliability
- Redundant network design (99.9% uptime SLA)
- Automatic failover within 30 seconds
- Dual ISP connectivity at main sites

#### Future-Ready
- IPv6 ready (dual-stack support)
- SD-WAN capable architecture
- IoT-ready network segmentation
- 5G integration capability

### 2.2 Security Requirements

#### Perimeter Security
- Next-generation firewall with IPS/IDS capability
- DDoS protection
- Web application firewall for public-facing services

#### Network Security
- Network segmentation for public/private traffic
- 802.1X authentication for wired and wireless
- Network access control (NAC)
- SIEM integration capability

#### Compliance
- Compliance with LGWAN security standards
- Support for government security audit requirements
- Encrypted management traffic

### 2.3 Service Requirements

#### Support
- 24/7 monitoring and support
- 4-hour on-site response for critical issues
- Dedicated account manager
- Japanese-language support required

#### Maintenance
- Quarterly security assessments
- Annual disaster recovery drills
- Firmware updates within 30 days of security patches
- Quarterly performance reviews

#### Documentation
- Complete network documentation
- Runbook for common procedures
- Training for city IT staff

---

## 3. Evaluation Criteria

| Criteria | Weight | Description |
|----------|--------|-------------|
| Technical Capability | 30% | Proposed solution meets all technical requirements |
| Price | 25% | Total cost of ownership over 5 years |
| Past Performance | 20% | Relevant experience with similar projects |
| Support & Maintenance | 15% | Quality of support plan and SLAs |
| Innovation | 10% | Forward-looking features and approaches |

### 3.1 Technical Evaluation (30%)
- Solution architecture quality
- Equipment specifications vs. requirements
- Security approach
- Scalability and future-proofing

### 3.2 Price Evaluation (25%)
- Initial implementation cost
- Annual maintenance and support costs
- 5-year total cost of ownership
- Cost breakdown transparency

### 3.3 Past Performance (20%)
- Similar project references (government preferred)
- Client testimonials
- Project completion track record
- Team experience

### 3.4 Support & Maintenance (15%)
- SLA commitments
- Support team structure
- Response time guarantees
- Escalation procedures

### 3.5 Innovation (10%)
- Technology roadmap alignment
- Innovative approaches to requirements
- Value-added features

---

## 4. Timeline

| Milestone | Date |
|-----------|------|
| RFP Release | January 15, 2025 |
| Questions Due | February 1, 2025 |
| Answers Published | February 8, 2025 |
| Proposal Due | February 28, 2025 |
| Evaluation Period | March 1-15, 2025 |
| Vendor Presentations | March 17-21, 2025 |
| Award Decision | March 31, 2025 |
| Contract Negotiation | April 1-14, 2025 |
| Project Start | April 15, 2025 |
| Phase 1 Complete (City Hall) | July 31, 2025 |
| Phase 2 Complete (Branch Offices) | October 31, 2025 |
| Phase 3 Complete (Community Centers) | December 31, 2025 |

---

## 5. Budget

- Estimated budget: 80-100 million JPY
- Budget includes: Equipment, installation, 3-year maintenance
- Payment terms: 30% upon contract, 40% upon Phase 1 completion, 30% upon final acceptance

---

## 6. Submission Requirements

### 6.1 Proposal Format
- Maximum 50 pages (excluding appendices)
- Japanese language required
- PDF format
- Include executive summary (2 pages max)

### 6.2 Required Sections
1. Executive Summary
2. Company Overview and Qualifications
3. Technical Approach
4. Project Plan and Timeline
5. Pricing (separate sealed document)
6. References (minimum 3 similar projects)
7. Team Structure
8. Draft SLA

### 6.3 Submission Method
- Electronic submission to: procurement@city.sendai.jp
- Pricing in separate email with "PRICING - CITY-2025-NET-001" subject
- Confirmation of receipt will be sent within 2 business days

---

## 7. Contact Information

**Procurement Office**
Sendai City Government
Information Technology Division
Email: procurement@city.sendai.jp
Phone: 022-XXX-XXXX

Questions must be submitted in writing by February 1, 2025.
