# Regional PR Strategy Guidelines

## Overview

This document provides PR strategy guidelines for each Tohoku prefecture, including key media contacts, effective topics, and best practices for regional coverage.

---

## Miyagi Prefecture (Sendai)

### Profile
- **Population:** 2.3 million
- **Capital:** Sendai (1.1 million)
- **Economic Focus:** Commerce, services, manufacturing
- **Characteristics:** Regional hub, highest media concentration

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Kahoku Shimpo | Newspaper | 420,000 | Press release + follow-up call |
| TBC TV (TBS affiliate) | Television | 600,000 viewers | Press conference preferred |
| OX TV (Fuji affiliate) | Television | 550,000 viewers | Press conference or pitch |
| Date FM | Radio | 200,000 listeners | Phone pitch |

### Effective Topics
1. **Urban innovation** - Smart city, technology adoption
2. **Business solutions** - Enterprise IT, DX initiatives
3. **Regional leadership** - Initiatives affecting broader Tohoku
4. **Economic development** - Job creation, investment

### Best Channels
- Press + TV combo for major announcements
- Newspaper-first for business stories
- Web/social for younger demographics

### Timing
- Weekday mornings (9-10 AM) for press releases
- Avoid Tanabata week (August) unless related
- Q4 budget cycles are busy for government coverage

### Tips
- Sendai media covers entire Tohoku region
- Strong competition - need clear news angle
- Kahoku Shimpo has significant regional influence

---

## Fukushima Prefecture

### Profile
- **Population:** 1.8 million
- **Capital:** Fukushima City (280,000)
- **Economic Focus:** Agriculture, manufacturing, energy
- **Characteristics:** Recovery and reconstruction focus

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Fukushima Minpo | Newspaper | 250,000 | Press release |
| Fukushima Minyu | Newspaper | 180,000 | Press release |
| Fukushima TV (FTV) | Television | 400,000 viewers | Pitch + visual story |
| Fukushima Central TV | Television | 350,000 viewers | Press release |

### Effective Topics
1. **Recovery and reconstruction** - Community rebuilding
2. **Community support** - CSR initiatives
3. **Renewable energy** - Solar, wind projects
4. **Agricultural revival** - Tech for farming

### Best Channels
- Local media + national pickup potential
- TV for visual stories (recovery progress)
- National wire services for broader reach

### Timing
- March (anniversary commemorations)
- Flexible timing generally
- Avoid Golden Week for non-urgent news

### Tips
- Recovery-related news gets high engagement
- National media interested in Fukushima stories
- Emphasize positive, forward-looking angles
- Community impact resonates strongly

---

## Iwate Prefecture

### Profile
- **Population:** 1.2 million
- **Capital:** Morioka (290,000)
- **Economic Focus:** Agriculture, manufacturing, tourism
- **Characteristics:** Large geographic area, rural focus

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Iwate Nippo | Newspaper | 200,000 | Press release + relationship |
| IBC TV (TBS affiliate) | Television | 300,000 viewers | Pitch meeting |
| Iwate Asahi TV | Television | 250,000 viewers | Press release |

### Effective Topics
1. **Rural connectivity** - Broadband expansion
2. **Regional development** - Infrastructure improvement
3. **Traditional industries** - Support for local business
4. **Tourism tech** - Digital tools for tourism

### Best Channels
- Local newspaper first (builds relationships)
- TV for human interest stories
- Limited web-first opportunities

### Timing
- Longer lead time needed (2-3 weeks)
- Summer festivals (Morioka Sansa) - related stories
- Winter: Transportation/connectivity stories

### Tips
- Strong interest in rural solutions
- Relationship building essential
- In-person meetings valued
- Regional dialect awareness helpful

---

## Akita Prefecture

### Profile
- **Population:** 950,000
- **Capital:** Akita City (300,000)
- **Economic Focus:** Agriculture (rice), forestry, tourism
- **Characteristics:** Aging population, traditional culture

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Akita Sakigake | Newspaper | 230,000 | Press release |
| AKT (Fuji affiliate) | Television | 250,000 viewers | Pitch + visual |
| ABS (Nippon TV) | Television | 220,000 viewers | Press release |

### Effective Topics
1. **Agriculture technology** - Smart farming, DX
2. **University partnerships** - Research collaboration
3. **Elderly support** - Technology for aging society
4. **Tourism innovation** - Digital tourism tools

### Best Channels
- Press release + web distribution
- TV for agricultural stories
- Local radio for community stories

### Timing
- Rice planting season (May-June) for agri stories
- Kanto Festival (August) - related coverage
- Avoid year-end harvest busy season

### Tips
- Strong interest in innovation topics
- Agricultural angle increases interest
- University (Akita International) connection valuable
- Emphasize practical, local benefits

---

## Yamagata Prefecture

### Profile
- **Population:** 1.1 million
- **Capital:** Yamagata City (250,000)
- **Economic Focus:** Agriculture (cherries, rice), manufacturing
- **Characteristics:** Strong local identity, food culture

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Yamagata Shimbun | Newspaper | 200,000 | Press release |
| YBC (Nippon TV) | Television | 280,000 viewers | Pitch |
| YTS (TV Asahi) | Television | 250,000 viewers | Press release |

### Effective Topics
1. **Agriculture innovation** - Cherry, fruit industry tech
2. **Tourism support** - Hot springs, skiing areas
3. **Local business DX** - SME digitalization
4. **Food industry** - Processing, distribution tech

### Best Channels
- Local newspaper + SNS amplification
- TV for food/tourism visual stories
- High SNS engagement in rural areas

### Timing
- Cherry season (June) for related stories
- Ski season (Dec-Feb) for tourism tech
- Flower season (April-May) timing

### Tips
- High SNS engagement opportunity
- Food angle always popular
- Local business stories resonate
- Onsen/hot spring tourism interest

---

## Aomori Prefecture

### Profile
- **Population:** 1.2 million
- **Capital:** Aomori City (280,000)
- **Economic Focus:** Fisheries, agriculture (apples), tourism
- **Characteristics:** Strong local festivals, seasonal economy

### Key Media
| Media | Type | Circulation/Reach | Contact Method |
|-------|------|-------------------|----------------|
| Daily Tohoku | Newspaper | 180,000 | Press release |
| RAB (Nippon TV) | Television | 300,000 viewers | Pitch |
| ATV (TV Asahi) | Television | 250,000 viewers | Press release |

### Effective Topics
1. **Fisheries technology** - Marine industry DX
2. **Tourism support** - Festival, seasonal tourism
3. **Regional service** - Infrastructure in rural areas
4. **Apple industry** - Agricultural technology

### Best Channels
- Local media (TV and newspaper)
- Seasonal timing critical
- Festival-related opportunities

### Timing
- Nebuta Festival (August) - prime time
- Apple harvest (Sept-Nov)
- Avoid extreme winter (Jan-Feb) unless relevant

### Tips
- Seasonal timing very important
- Festival connection increases interest
- Fisheries angle for coastal stories
- Weather impacts news cycles significantly

---

## Cross-Regional Strategies

### Multi-Prefecture Announcements
1. Lead with Sendai (Kahoku Shimpo)
2. Simultaneous release to other prefectures
3. Customize local angles for each
4. Coordinate timing across regions

### Best Practices
- Build relationships with key journalists
- Understand local calendar and seasons
- Customize messaging for regional priorities
- Track which angles work in each area
- Document successful approaches

### Regional Media Partnerships
- Offer exclusive local angles
- Provide spokesperson availability
- Support with local data/statistics
- Follow up personally on major stories
