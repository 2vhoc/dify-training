# Publicity Effectiveness Metrics

## Overview

This document defines the key metrics used to evaluate publicity effectiveness across the Tohoku region.

---

## Reach Metrics

### Media Pickup Rate

**Definition:** Percentage of press releases that receive media coverage

**Calculation:**
```
Media Pickup Rate = (Number of Media Mentions / Number of Press Releases) × 100
```

**Benchmarks:**
| Rating | Percentage |
|--------|------------|
| Excellent | > 80% |
| Good | 60-80% |
| Average | 40-59% |
| Below Average | 20-39% |
| Poor | < 20% |

**Improvement Strategies:**
- Better headline writing
- Stronger news angle
- More targeted media outreach
- Better timing of release

---

### Reach Volume

**Definition:** Estimated total audience reached by coverage

**Calculation:**
```
Reach Volume = Σ (Media Circulation × Multiplier)
```

**Media Type Multipliers:**
| Media Type | Multiplier | Rationale |
|------------|------------|-----------|
| National media | 1.5x | Higher credibility, wider reach |
| Regional TV | 1.2x | Visual impact, repeat viewing |
| Regional newspaper | 1.0x | Baseline |
| Web only | 0.8x | Lower engagement, shorter attention |
| Trade/specialty | 0.7x | Narrow audience |

**Data Sources:**
- Newspaper: Official circulation data
- TV: Viewership ratings (average for time slot)
- Web: Unique visitors (from analytics or media kit)

---

### Geographic Distribution

**Definition:** Coverage spread across Tohoku prefectures

**Calculation:**
```
Geographic Distribution Score = (Prefectures with Coverage / 6) × 100
```

**Tracking:**
- Track which prefectures receive coverage
- Identify gaps in coverage
- Target underserved areas

---

## Quality Metrics

### Sentiment Score

**Definition:** Average sentiment of media coverage and social mentions

**Scoring Scale:**
| Sentiment | Score | Criteria |
|-----------|-------|----------|
| Very Positive | 5 | Enthusiastic, recommends, praises |
| Positive | 4 | Generally favorable, highlights benefits |
| Neutral | 3 | Factual reporting, balanced |
| Negative | 2 | Critical, highlights problems |
| Very Negative | 1 | Strongly critical, damaging |

**Target:** Average sentiment score > 3.5

**Analysis Factors:**
- Headline tone
- Quote selection
- Context framing
- Overall article balance

---

### Message Retention Rate

**Definition:** Percentage of coverage that includes key messages

**Calculation:**
```
Message Retention Rate = (Coverage with Key Message / Total Coverage) × 100
```

**Scoring:**
| Retention Level | Percentage |
|-----------------|------------|
| Full retention | 100% |
| Partial retention | 50% |
| No key message | 0% |

**Key Message Checklist:**
- [ ] Primary message present
- [ ] Brand mentioned correctly
- [ ] Call-to-action included
- [ ] Statistics/facts accurate
- [ ] Correct spokesperson quoted

**Target:** > 70% retention rate

---

### Share of Voice

**Definition:** Company mentions compared to competitors in same topic area

**Calculation:**
```
Share of Voice = (Company Mentions / Total Industry Mentions) × 100
```

**Uses:**
- Competitive benchmarking
- Topic leadership tracking
- Campaign effectiveness

---

## Engagement Metrics

### Social Media Engagement Rate

**Definition:** Interaction level with social content

**Calculation:**
```
Engagement Rate = (Likes + Comments + Shares) / Reach × 100
```

**Benchmarks:**
| Rating | Percentage |
|--------|------------|
| Excellent | > 5% |
| Good | 2-5% |
| Average | 1-2% |
| Below Average | < 1% |

---

### Amplification Rate

**Definition:** Content sharing/spread beyond initial audience

**Calculation:**
```
Amplification Rate = Shares / Total Engagement × 100
```

**Significance:**
- Higher rate = message spreading organically
- Indicates resonance with audience
- More valuable than simple likes

---

### Conversation Rate

**Definition:** Comments and replies relative to other engagement

**Calculation:**
```
Conversation Rate = Comments / Total Engagement × 100
```

**Significance:**
- Indicates audience investment
- Opportunity for relationship building
- Source of feedback

---

## Effectiveness Scoring

### Overall Effectiveness Score

**Calculation:**
```
Effectiveness Score = (Reach Score × 0.3) +
                      (Quality Score × 0.4) +
                      (Engagement Score × 0.3)
```

**Component Scores (each 0-100):**

**Reach Score:**
- Pickup rate (40%)
- Reach volume vs. target (40%)
- Geographic distribution (20%)

**Quality Score:**
- Sentiment (40%)
- Message retention (40%)
- Share of voice (20%)

**Engagement Score:**
- Engagement rate (50%)
- Amplification rate (30%)
- Conversation rate (20%)

---

### Performance Categories

| Score Range | Category | Action |
|-------------|----------|--------|
| 90-100 | Outstanding | Document as best practice |
| 80-89 | Excellent | Minor optimization needed |
| 70-79 | Good | Meets expectations |
| 60-69 | Satisfactory | Improvement opportunities |
| 50-59 | Needs Improvement | Strategy review required |
| < 50 | Underperforming | Significant changes needed |

---

## Reporting Frequency

| Report Type | Frequency | Contents |
|-------------|-----------|----------|
| Campaign Report | Per campaign | All metrics for specific campaign |
| Monthly Summary | Monthly | Aggregate metrics, trends |
| Quarterly Analysis | Quarterly | Deep dive, recommendations |
| Annual Review | Annually | Year-over-year comparison, strategy |

---

## Data Collection Tools

### Tracking Sources
- Media monitoring service (e.g., Meltwater, Cision)
- Social media analytics (native + tools)
- Web analytics (Google Analytics)
- Survey data (brand awareness studies)

### Documentation
- Centralized tracking spreadsheet
- Media clip archive
- Social mention log
- Coverage screenshots
