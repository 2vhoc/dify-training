# DX Entry Sheet Guidelines

## Required Fields

### 1. Project Title
- Clear and concise (under 50 characters)
- Should indicate the automation/improvement target
- Format: [Action] + [Target Process/System]
- Example: "Automate Customer Visit Report Generation"

### 2. Current Problem Description
Required elements:
- Specific process being addressed
- Quantified current state (time, cost, error rate)
- Who is affected (stakeholders)
- Frequency of the problem

Good example: "Sales representatives spend 2 hours daily writing customer visit reports manually. This affects 50 sales staff across 6 branches."

Bad example: "Report writing is slow."

### 3. Proposed Solution
Required elements:
- Technology/approach to be used
- How it addresses the problem
- Scope (which processes, which departments)
- Integration requirements (if any)

Good example: "Implement AI-assisted report generation using voice input and templates. Sales staff will record visit notes via mobile app, and AI will generate structured reports automatically."

Bad example: "Use AI to make it faster."

### 4. Expected Effect (KPIs)
Required elements:
- Specific metrics with target numbers
- Measurement method
- Timeline for achieving results
- Baseline comparison

Good example: "Reduce report writing time from 2 hours to 30 minutes (75% reduction) within 3 months of deployment. Measurement: Average time per report tracked in the system."

Bad example: "Will be faster."

### 5. Required Resources
- Budget estimate (initial + ongoing)
- Personnel requirements (internal + external)
- Timeline (development, testing, deployment)
- External support needs (vendors, consultants)

## Evaluation Criteria

| Criteria | Weight | Description |
|----------|--------|-------------|
| Problem Clarity | 25% | Is the problem well-defined and quantified? |
| Solution Feasibility | 25% | Is the proposed solution realistic? |
| Expected Impact | 25% | Are KPIs clear and achievable? |
| Resource Planning | 15% | Are resource needs realistic? |
| Alignment | 10% | Does it align with company DX strategy? |

## Scoring Guide

### Problem Clarity (25 points)
- 25: Specific process, quantified impact, clear stakeholders
- 20: Good description but missing some quantification
- 15: General description, some specifics missing
- 10: Vague description, minimal quantification
- 5: No clear problem definition

### Solution Feasibility (25 points)
- 25: Clear technical approach, realistic scope, good integration plan
- 20: Good approach but some details missing
- 15: General approach, feasibility concerns
- 10: Unclear approach, significant feasibility questions
- 5: Unrealistic or undefined solution

### Expected Impact (25 points)
- 25: Specific KPIs, measurement plan, realistic timeline
- 20: Good KPIs but measurement plan incomplete
- 15: General benefits stated, weak quantification
- 10: Vague benefits, no measurable outcomes
- 5: No expected outcomes defined

### Resource Planning (15 points)
- 15: Complete budget, timeline, personnel plan
- 12: Most elements present, some gaps
- 9: Partial planning, major elements missing
- 6: Minimal planning
- 3: No resource planning

### Alignment (10 points)
- 10: Clear alignment with DX strategy
- 8: Good alignment, minor gaps
- 6: Partial alignment
- 4: Weak alignment
- 2: No alignment demonstrated

## Common Rejection Reasons

1. **Vague problem description without data**
   - Solution: Include specific numbers (time, cost, frequency, affected users)

2. **No measurable success criteria**
   - Solution: Define KPIs with target values and measurement methods

3. **Unrealistic timeline or expectations**
   - Solution: Research similar projects, consult with IT on technical feasibility

4. **Missing stakeholder analysis**
   - Solution: Identify who will use the solution, who will be affected, who needs to approve

5. **No consideration of risks or constraints**
   - Solution: List potential risks and mitigation strategies

6. **Technology-first approach without business justification**
   - Solution: Start with the business problem, then explain why the technology fits

## Application Checklist

Before submitting, verify:

- [ ] Project title is clear and under 50 characters
- [ ] Problem includes quantified current state
- [ ] Problem identifies affected stakeholders
- [ ] Solution describes specific technology/approach
- [ ] Solution explains how it addresses the problem
- [ ] KPIs include specific target numbers
- [ ] KPIs include measurement method
- [ ] Timeline is defined with milestones
- [ ] Budget estimate is provided
- [ ] Required resources are identified
- [ ] Risks are acknowledged
- [ ] Alignment with company strategy is explained
