# Accounting Code Selection Rules

## Decision Tree Approach

### Step 1: Is it a capital purchase?

```
Is the item:
- Over 100,000 JPY AND
- Has useful life > 1 year?
        |
    YES → Use 42xxx codes (Asset Purchases)
        |
    NO  → Continue to Step 2
```

### Step 2: What is the primary purpose?

```
Primary Purpose:
    |
    ├── IT/Software related → Use 43xxx codes
    |       ├── Software purchase/subscription → 43201
    |       └── Hardware maintenance → 43301
    |
    ├── Personnel related → Use 41301 (Temporary Personnel)
    |
    ├── Facility related → Use 45xxx codes
    |       ├── Rent/lease → 45101
    |       └── Building maintenance → 45201
    |
    └── General operational → Use 44xxx codes
            ├── Travel → 44101
            ├── Training → 44201
            ├── Daily transport/communication → 44301
            ├── Entertainment → 44401
            ├── Professional services → 44501
            └── Marketing → 44601
```

### Step 3: Specific Category Selection (Common Confusion Areas)

---

## Travel vs Training (44101 vs 44201)

**Key Question:** What is the PRIMARY purpose of the expense?

| Scenario | Code | Rationale |
|----------|------|-----------|
| Attending seminar as PARTICIPANT | 44201 | Learning is primary purpose |
| Traveling to GIVE presentation | 44101 | Travel is primary purpose |
| Conference with learning + networking | 44201 | Learning is primary |
| Client visit for project work | 44101 | Travel for business activity |

**Special Case - Conference with Both:**
- Registration fee → 44201 (Training)
- Travel costs → 44101 (Travel)
- Split the expense by purpose

---

## Equipment vs Consumables (42101 vs 41101)

**Key Questions:**
1. What is the unit price?
2. What is the expected useful life?

| Unit Price | Useful Life | Code | Category |
|------------|-------------|------|----------|
| < 10,000 JPY | < 1 year | 41101 | Consumables |
| 10,000 - 100,000 JPY | < 1 year | 41101 | Consumables |
| 10,000 - 100,000 JPY | > 1 year | 42101 | Equipment |
| > 100,000 JPY | Any | 42101 | Equipment |

**Examples:**
- Keyboard (8,000 JPY) → 41101 (Consumables)
- Monitor (35,000 JPY, 3-year life) → 42101 (Equipment)
- Laptop (150,000 JPY) → 42101 (Equipment)
- Printer ink (5,000 JPY) → 41101 (Consumables)

---

## Maintenance vs Software (43301 vs 43201)

**Key Question:** Is it for HARDWARE or SOFTWARE?

| Item | Code | Rationale |
|------|------|-----------|
| Server hardware maintenance | 43301 | Physical equipment |
| Software maintenance fee | 43201 | Software related |
| SaaS subscription | 43201 | Software service |
| Network equipment support | 43301 | Physical equipment |
| Cloud hosting (AWS, Azure) | 43201 | Software/service |

**Combined Maintenance Contracts:**
- If contract covers BOTH hardware + software:
  - Split if amounts are clear
  - Use 43301 if hardware is primary
  - Use 43201 if software is primary

---

## Consulting vs Training (44501 vs 44201)

**Key Question:** Is someone TEACHING us or DOING work for us?

| Scenario | Code | Rationale |
|----------|------|-----------|
| External training instructor | 44201 | Teaching our employees |
| Consultant doing assessment | 44501 | Doing work for us |
| Workshop facilitation | 44201 | Learning activity |
| System implementation consulting | 44501 | Professional service |
| Certification prep course | 44201 | Training/education |

---

## Common Clarification Questions

When uncertain, ask these questions:

1. **What is the unit price of the item?**
   - Determines Equipment vs Consumables boundary

2. **What is the expected useful life?**
   - >1 year suggests Equipment or Asset

3. **What is the primary purpose of the expense?**
   - Learning → Training
   - Business activity → Travel or relevant operational code
   - Getting expert help → Professional Services

4. **Is this a recurring or one-time expense?**
   - Recurring often suggests subscriptions or maintenance
   - One-time might be asset purchase or project expense

5. **Which department will use this?**
   - Helps determine appropriate budget category

6. **Is this for internal use or client-facing?**
   - Client-facing often → Entertainment or Marketing

---

## Error Prevention Checklist

Before finalizing a code selection:

- [ ] Verified unit price against thresholds
- [ ] Confirmed useful life expectation
- [ ] Identified primary purpose correctly
- [ ] Checked for similar past transactions
- [ ] Considered if expense should be split
- [ ] Verified against department budget categories

---

## Common Mistakes and Corrections

| Common Mistake | Correct Approach |
|----------------|------------------|
| All travel as 44101 | Split training registration (44201) from travel costs (44101) |
| All IT as 43201 | Hardware maintenance is 43301, software is 43201 |
| Expensive supplies as 41101 | Check if >100,000 JPY → 42101 |
| Consulting as 44201 | Training is 44201, consulting work is 44501 |
| Combined contracts single code | Split by primary purpose if amounts are known |

---

## When to Escalate

Contact Finance Department when:

- Transaction > 1,000,000 JPY
- Uncertain after using decision tree
- New type of transaction not in guidelines
- Cross-departmental expense allocation needed
- International transaction with tax implications
- Retroactive correction needed

**Finance Contact:**
- Email: finance-inquiry@example.internal
- Phone: ext. 3333
- Response time: Within 2 business days
