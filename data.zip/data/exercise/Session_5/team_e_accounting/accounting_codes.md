# Accounting Code Reference

## Code Structure

Format: XXXXX (5 digits)
- First 2 digits: Major category
- Next 2 digits: Sub-category
- Last digit: Specific type

---

## 41000 - General Expenses

### 41101 - Consumables
**Definition:** Non-durable goods used in daily operations
**Criteria:**
- Items under 10,000 JPY unit price
- Expected useful life < 1 year
- Consumed through use

**Examples:**
- Paper, pens, office supplies
- Printer ink and toner (under 10,000 JPY)
- Cleaning supplies
- Batteries, small tools

**NOT This Code:**
- Items > 10,000 JPY (see Equipment)
- Items with useful life > 1 year

---

### 41201 - Utilities
**Definition:** Facility-related utility costs

**Examples:**
- Electricity bills
- Gas bills
- Water bills
- Utility deposits

**NOT This Code:**
- Mobile phone bills (see 44301 Transportation/Communication)
- Internet service (see 43201 Software/Services)

---

### 41301 - Personnel (Temporary)
**Definition:** Wages for temporary or part-time workers

**Examples:**
- Temporary staff wages
- Part-time worker payments
- Seasonal employee costs
- Temp agency fees

**NOT This Code:**
- Full-time employee salary (different expense category)
- Consultant fees (see 44501)

---

## 42000 - Asset Purchases

### 42101 - Equipment
**Definition:** Durable goods with significant value

**Criteria:**
- Unit price > 100,000 JPY OR
- Expected useful life > 1 year
- Tangible asset

**Examples:**
- Computers (desktop, laptop)
- Printers, copiers
- Office furniture
- Phones and communication devices
- Test equipment

**NOT This Code:**
- Software (see 43201)
- Items < 10,000 JPY (see Consumables)

---

### 42201 - Vehicles
**Definition:** Company vehicles and related capital expenses

**Examples:**
- Company cars
- Vans and trucks
- Vehicle modifications for business use
- Vehicle registration costs

**NOT This Code:**
- Fuel (see 44301)
- Vehicle repairs (see 45201)

---

## 43000 - IT & Software

### 43201 - Software
**Definition:** Software licenses and subscriptions

**Examples:**
- Software license purchases
- SaaS subscriptions (Microsoft 365, etc.)
- Cloud service fees (AWS, Azure)
- Software maintenance fees
- App subscriptions

**NOT This Code:**
- Hardware maintenance (see 43301)
- Custom software development (see 44501)

---

### 43301 - Equipment Maintenance
**Definition:** Maintenance contracts for hardware and equipment

**Examples:**
- Server maintenance contracts
- Network equipment maintenance
- Printer/copier maintenance
- Annual hardware support agreements
- Equipment repair services

**NOT This Code:**
- Software maintenance (see 43201)
- Building maintenance (see 45201)

---

## 44000 - Operational Expenses

### 44101 - Travel
**Definition:** Business travel expenses

**Examples:**
- Transportation costs (train, flight, taxi)
- Accommodation
- Per diem expenses
- Conference attendance travel
- Client visit travel

**NOT This Code:**
- Seminar registration fees (see 44201)
- Daily commuting (see 44301)
- Client entertainment during trip (see 44401)

---

### 44201 - Training & Development
**Definition:** Employee skill development expenses

**Examples:**
- Seminar registration fees
- Training course fees
- Certification exam costs
- E-learning subscriptions
- Training materials
- Conference registration (as participant)

**NOT This Code:**
- Travel to training (see 44101)
- Books and magazines (see 41101)

---

### 44301 - Transportation (Daily)
**Definition:** Regular transportation and communication costs

**Examples:**
- Fuel expenses (company vehicles)
- Parking fees
- Commuting support/subsidies
- Local travel (within city)
- Mobile phone bills
- Toll fees

**NOT This Code:**
- Long-distance business travel (see 44101)
- Vehicle purchases (see 42201)

---

### 44401 - Entertainment
**Definition:** Business entertainment expenses

**Examples:**
- Client meals and dinners
- Business entertainment
- Business gifts
- Golf/activity with clients
- Holiday gifts to business partners

**NOT This Code:**
- Internal team events (separate budget)
- Employee meals during travel (see 44101)

---

### 44501 - Professional Services
**Definition:** External professional expertise

**Examples:**
- Consulting fees
- Legal fees
- Audit expenses
- Custom development services
- Design services
- Translation services

**NOT This Code:**
- Temporary staffing (see 41301)
- Training services (see 44201)

---

### 44601 - Advertising & Marketing
**Definition:** Promotional and marketing expenses

**Examples:**
- Advertising costs (print, digital)
- Promotional materials
- Marketing campaigns
- Trade show booth fees
- Brochures and flyers
- PR agency fees

**NOT This Code:**
- Client entertainment (see 44401)
- Event travel (see 44101)

---

## 45000 - Facility Expenses

### 45101 - Rent
**Definition:** Property lease payments

**Examples:**
- Office rent
- Warehouse rent
- Parking space rental
- Storage unit rental
- Equipment rental (long-term)

**NOT This Code:**
- Short-term equipment rental (see 44301)
- Utility costs (see 41201)

---

### 45201 - Facility Maintenance
**Definition:** Building and facility upkeep

**Examples:**
- Building repairs
- HVAC maintenance
- Cleaning services (contracted)
- Security services
- Landscaping
- Elevator maintenance
- Fire equipment inspection

**NOT This Code:**
- Equipment maintenance (see 43301)
- Office supplies (see 41101)

---

## Quick Reference Table

| Transaction Type | Code | Key Criteria |
|-----------------|------|--------------|
| Office supplies | 41101 | <10,000 JPY, consumable |
| Computer purchase | 42101 | >100,000 JPY or >1 year life |
| Software license | 43201 | Software, SaaS, cloud |
| Server maintenance | 43301 | Hardware maintenance contract |
| Business trip | 44101 | Transportation + accommodation |
| Seminar fee | 44201 | Learning/development purpose |
| Fuel expense | 44301 | Daily transportation |
| Client dinner | 44401 | Business entertainment |
| Consultant fee | 44501 | External professional service |
| Marketing materials | 44601 | Promotional purpose |
| Office rent | 45101 | Property lease |
| Building repair | 45201 | Facility maintenance |
