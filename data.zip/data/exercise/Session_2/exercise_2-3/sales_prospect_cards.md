# Sales Prospect Cards

Copy-paste one prospect card at a time into the Agent chat, then ask research questions about that prospect's region, industry, or competitors.

---

## [Prospect 1] Sendai Smart City Project

- **Client:** Sendai City Government, Urban Development Division
- **Need:** IoT sensor network for traffic monitoring in downtown area
- **Budget range:** 50-80 million yen
- **Timeline:** FY2025 Q3 start
- **Key contact:** Mr. Abe, Division Manager
- **Notes:** Competitor already presented. Need differentiator.

**Sample Research Questions:**
- Research Sendai smart city initiatives and competitor telecom offerings
- What IoT traffic monitoring solutions are being used in other Japanese cities?
- Find recent news about Sendai urban development projects

---

## [Prospect 2] Akita Agricultural Cooperative DX

- **Client:** JA Akita Agricultural Cooperative
- **Need:** Tablet-based field management system with cloud connectivity
- **Budget range:** 10-20 million yen
- **Timeline:** Before rice planting season (April 2025)
- **Key contact:** Ms. Saito, IT Planning
- **Notes:** Currently using paper-based records. 200+ member farms.

**Sample Research Questions:**
- What is the current adoption rate of agricultural DX in Akita Prefecture?
- Find examples of successful smart farming implementations in Japan
- What are common challenges for agricultural cooperatives adopting digital tools?

---

## [Prospect 3] Yamagata Hotel Chain Wi-Fi Upgrade

- **Client:** Yamagata Onsen Resort Group (5 hotels)
- **Need:** High-speed guest Wi-Fi + staff communication network
- **Budget range:** 15-30 million yen
- **Timeline:** Before tourism peak (July 2025)
- **Key contact:** Mr. Kato, Facilities Manager
- **Notes:** Current system is 8 years old. Frequent guest complaints.

**Sample Research Questions:**
- How many tourist visitors does Yamagata receive annually?
- Calculate potential Wi-Fi users if each hotel has 100 rooms at 70% occupancy
- What Wi-Fi standards do luxury hotels typically implement?

---

## [Prospect 4] Iwate Prefectural Hospital Network

- **Client:** Iwate Medical University Hospital
- **Need:** Secure high-bandwidth network for telemedicine
- **Budget range:** 100-150 million yen
- **Timeline:** FY2025-2026 phased deployment
- **Key contact:** Dr. Mori, IT Committee Chair
- **Notes:** Government subsidy available. Must meet medical data security standards.

**Sample Research Questions:**
- What are the telemedicine regulations and network requirements for medical institutions in Japan?
- Find examples of hospital network implementations in regional areas
- What security certifications are required for medical network systems?

---

## [Prospect 5] Fukushima Renewable Energy Monitoring

- **Client:** Fukushima Energy Partners LLC
- **Need:** Remote monitoring system for 12 solar farms
- **Budget range:** 20-40 million yen
- **Timeline:** FY2025 Q2
- **Key contact:** Mr. Honda, Operations Director
- **Notes:** Sites spread across 3 municipalities. Requires low-latency connectivity.

**Sample Research Questions:**
- Estimate data bandwidth needed for monitoring 12 solar farms with 100 sensors each sending data every 5 minutes
- What communication technologies are used for remote solar farm monitoring?
- Find information about renewable energy growth in Fukushima Prefecture
