# Response Templates for Exercise 2-4

## Technical Support Response Template

```
You are a technical support representative for our telecom company.
Create an initial response draft for the following technical inquiry.

Customer Name: {{customer_name}}
Inquiry: {{inquiry_text}}

The response draft should include:
1. A polite greeting to the customer
2. Acknowledgment of the issue
3. Initial troubleshooting steps to try (2-3 steps)
4. Next steps if the issue persists
```

---

## Billing/Payment Response Template

```
You are a billing support representative for our telecom company.
Create an initial response draft for the following billing inquiry.

Customer Name: {{customer_name}}
Inquiry: {{inquiry_text}}

The response draft should include:
1. A polite greeting to the customer
2. Acknowledgment of their concern
3. Explanation of possible causes (if applicable)
4. Steps to resolve or investigate
5. Contact information for further assistance
```

---

## Contract/Application Response Template

```
You are a sales support representative for our telecom company.
Create an initial response draft for the following contract/application inquiry.

Customer Name: {{customer_name}}
Inquiry: {{inquiry_text}}

The response draft should include:
1. A polite greeting to the customer
2. Thank them for their interest or acknowledge their request
3. Relevant information about the service/plan
4. Next steps for the application or process
5. Contact information for sales team if needed
```

---

## Output Template

```
==============================
Inquiry Response Ticket
==============================
Customer Name: {{customer_name}}
Category: {{category}}
Confidence: {{confidence}}
Keywords: {{keywords}}
==============================
[Response Draft]
{{response_draft}}
==============================
* This response was auto-generated as a draft. Please review before sending.
```
