# Classification Categories for Exercise 2-4

## Category Definitions

### 1. Technical Support
**Keywords:** internet, speed, slow, connection, Wi-Fi, router, equipment, blinking, red light, disconnection, outage, signal, static, noise, VoIP, phone dropping

**Examples:**
- Connection issues
- Equipment failures
- Speed problems
- Wi-Fi problems
- VoIP quality issues

**Response Focus:** Troubleshooting steps, technical verification, repair scheduling

---

### 2. Billing/Payment
**Keywords:** bill, charge, payment, price, fee, invoice, refund, duplicate, higher, increase, cost, subscription

**Examples:**
- Bill amount questions
- Payment method changes
- Pricing plan inquiries
- Refund requests
- Billing errors

**Response Focus:** Billing explanation, correction process, payment options

---

### 3. Contract/Application
**Keywords:** apply, new, cancel, change, plan, contract, move, subscribe, bundle, discount, upgrade, downgrade

**Examples:**
- New service applications
- Plan changes
- Service cancellations
- Moving/relocation
- Bundle inquiries

**Response Focus:** Application guidance, plan options, process explanation

---

## Workflow Configuration

### Start Node Input Variables

| Variable | Type | Label |
|----------|------|-------|
| inquiry_text | Paragraph | Inquiry Content |
| customer_name | Text | Customer Name |

### LLM Classification Prompt

```
Classify the following customer inquiry into one of these 3 categories:

Categories:
- Technical Support (connection issues, equipment failures, speed problems, etc.)
- Billing/Payment (bill amounts, payment methods, pricing plans, etc.)
- Contract/Application (new applications, plan changes, cancellations, etc.)

Inquiry content:
{{inquiry_text}}

Respond in the following JSON format:
{"category": "category_name", "confidence": "high/medium/low", "keywords": ["keyword1", "keyword2"]}
```

### IF/ELSE Conditions

| Condition | Branch |
|-----------|--------|
| category contains "Technical" | Technical Support Response |
| category contains "Billing" | Billing Response |
| Default | Contract/Application Response |
