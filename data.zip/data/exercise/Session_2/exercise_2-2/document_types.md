# Document Types for Exercise 2-2

## Available Document Types

Use the dropdown options below when configuring the Text Generator input form.

### 1. Maintenance Report
- Used for: Field technician work documentation
- Data source: maintenance_records.csv
- Key fields: ticket_id, equipment_type, location, issue_description, action_taken, technician, work_date

### 2. Transaction Record
- Used for: Financial transaction documentation
- Data source: transaction_records.csv
- Key fields: transaction_id, description, department, amount_jpy, purpose, date, requester

### 3. Meeting Minutes
- Used for: Meeting documentation
- Key fields: meeting_title, date, attendees, discussion_points, decisions, action_items

### 4. Status Report
- Used for: Project or task status updates
- Key fields: project_name, period, progress, issues, next_steps, responsible_person

### 5. Expense Summary
- Used for: Travel or expense consolidation
- Key fields: trip_purpose, dates, expenses_breakdown, total_amount, approver

---

## Input Variable Configuration

| Variable Name | Type | Label | Notes |
|--------------|------|-------|-------|
| document_type | Dropdown | Document Type | Use list above |
| subject | Text | Subject/Title | Brief description |
| details | Paragraph | Details/Description | Main content |
| responsible_person | Text | Responsible Person | Who is accountable |
| date | Text | Date | YYYY-MM-DD format |
| additional_notes | Paragraph | Additional Notes | Optional extra info |
