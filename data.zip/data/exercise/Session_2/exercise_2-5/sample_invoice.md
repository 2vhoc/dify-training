# Sample Invoice Document
## For Doc Extractor Exercise

**INVOICE**

---

**Invoice Number:** INV-2025-0042
**Invoice Date:** January 15, 2025
**Due Date:** February 15, 2025

---

**From:**
Regional Telecom Company
1-2-3 Aoba-ku, Sendai City
Miyagi Prefecture, 980-0001
TEL: 022-123-4567

**Bill To:**
Yamamoto Manufacturing Co., Ltd.
4-5-6 Wakabayashi-ku, Sendai City
Miyagi Prefecture, 984-0001
Attn: Mr. Kenji Yamamoto

---

| Item | Description | Quantity | Unit Price | Amount |
|------|-------------|----------|------------|--------|
| 1 | FLET'S Hikari Next (Monthly) | 1 | ¥5,940 | ¥5,940 |
| 2 | Hikari Denwa Basic (Monthly) | 1 | ¥550 | ¥550 |
| 3 | VPN Service (Monthly) | 1 | ¥3,300 | ¥3,300 |
| 4 | Equipment Rental - Router | 1 | ¥550 | ¥550 |
| 5 | Additional IP Address | 3 | ¥330 | ¥990 |

---

**Subtotal:** ¥11,330
**Tax (10%):** ¥1,133
**Total Amount Due:** ¥12,463

---

**Payment Methods:**
- Bank Transfer: Tohoku Bank, Sendai Branch, Account 1234567
- Credit Card: Via customer portal
- Convenience Store: Payment slip enclosed

**Notes:**
- Payment is due within 30 days of invoice date
- For questions, contact billing@regionaltelecom.jp

---
*Thank you for your business.*
