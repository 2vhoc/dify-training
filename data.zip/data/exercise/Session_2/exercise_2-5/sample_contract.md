# Service Agreement Contract
## For Doc Extractor Exercise

---

**SERVICE AGREEMENT**

**Agreement Number:** SA-2025-0018
**Effective Date:** February 1, 2025
**Expiration Date:** January 31, 2028

---

## PARTIES

**Service Provider:**
Regional Telecom Company
1-2-3 Aoba-ku, Sendai City, Miyagi Prefecture 980-0001
Representative: President Taro Suzuki

**Customer:**
Tohoku Trading Corporation
7-8-9 Taihaku-ku, Sendai City, Miyagi Prefecture 982-0001
Representative: President Hanako Tanaka

---

## ARTICLE 1: SERVICE DESCRIPTION

The Service Provider agrees to provide the following telecommunications services:

1. **Internet Service:** FLET'S Hikari Next Business Type
   - Bandwidth: Up to 1Gbps symmetrical
   - IP Addresses: 8 static IPv4 addresses

2. **Voice Service:** Hikari Denwa Office Type
   - Channels: 8 simultaneous channels
   - Numbers: 16 telephone numbers

3. **VPN Service:** FLET'S VPN Wide
   - Sites: 3 locations (Sendai HQ, Ishinomaki Branch, Kesennuma Branch)

---

## ARTICLE 2: CONTRACT TERM

1. This Agreement shall be effective for a period of **three (3) years**
2. Auto-renewal for successive one-year terms unless terminated with 90 days notice

---

## ARTICLE 3: FEES AND PAYMENT

| Service | Monthly Fee | Initial Cost |
|---------|-------------|--------------|
| Internet | ¥8,800 | ¥33,000 |
| Voice | ¥5,500 | ¥16,500 |
| VPN (3 sites) | ¥22,000 | ¥55,000 |
| **Total** | **¥36,300** | **¥104,500** |

- All prices include 10% consumption tax
- Payment due by the 25th of each month
- Late payment fee: 14.6% annual rate

---

## ARTICLE 4: SERVICE LEVEL AGREEMENT (SLA)

1. **Availability:** 99.9% monthly uptime guarantee
2. **Response Time:** 4 hours for critical issues
3. **Credit:** 10% monthly credit for each 0.1% below SLA

---

## ARTICLE 5: TERMINATION

1. **Early Termination Fee:** Remaining months × ¥10,000
2. **90 days written notice required**
3. Customer responsible for equipment return within 30 days

---

## SIGNATURES

Service Provider: ___________________ Date: ___________
Customer: ___________________ Date: ___________

---
*This is a sample document for training purposes only.*
