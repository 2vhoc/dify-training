# Doc Extractor Node Guide
## For Exercise 2-5

## What is Doc Extractor?

The **Doc Extractor** node in Dify Kanade parses and extracts text content from various document formats. It converts unstructured documents into text that LLM nodes can process.

## Supported File Formats

| Format | Extension | Use Case |
|--------|-----------|----------|
| PDF | .pdf | Contracts, reports, manuals |
| Word | .docx | Business documents, proposals |
| Excel | .xlsx | Data tables, equipment lists |
| PowerPoint | .pptx | Presentations, training materials |
| CSV | .csv | Structured data, records |
| Markdown | .md | Technical documentation |
| Text | .txt | Plain text files |

## Node Configuration

### Input Variables
- **File**: The uploaded file to process
- Accepts single file or file array for batch processing

### Output Variables
- **text**: Extracted text content from the document

## Best Practices

### 1. Pre-processing Strategy
- Check document quality before processing
- Remove password protection from PDFs
- Ensure tables are properly formatted in Excel

### 2. Post-processing with LLM
After extraction, use an LLM node to:
- Structure the extracted text
- Extract specific fields (dates, amounts, names)
- Summarize long documents

### 3. Error Handling
- Add IF/ELSE node to check for empty extraction
- Provide fallback message for unsupported formats

## Common Extraction Tasks

### Invoice Processing
Extract: Invoice number, date, vendor, line items, total amount

### Contract Analysis
Extract: Party names, effective dates, terms, obligations

### Meeting Minutes
Extract: Date, attendees, agenda items, action items, decisions

### Equipment Inventory
Extract: Equipment ID, name, status, location, warranty info

## Workflow Pattern

```
[Start: File Upload]
        |
[Doc Extractor: Parse Document]
        |
[LLM: Extract Structured Data]
        |
[Template: Format Output]
        |
[End: Structured Result]
```
