# Meeting Minutes
## For Doc Extractor Exercise

---

**Meeting Title:** Monthly Project Status Review
**Date:** January 20, 2025
**Time:** 10:00 - 11:30
**Location:** Conference Room A, 5F / Microsoft Teams Hybrid

---

## ATTENDEES

| Name | Department | Role | Attendance |
|------|------------|------|------------|
| Taro Yamada | DX Promotion | Meeting Chair | In-person |
| Hanako Suzuki | IT | Technical Lead | In-person |
| Kenji Sato | Sales | Account Manager | Online |
| Yuki Tanaka | Finance | Budget Coordinator | Online |
| Akira Watanabe | Operations | Project Manager | In-person |

**Absent:** Misaki Ito (Customer Service) - on leave

---

## AGENDA

1. Previous action item review
2. Project Alpha status update
3. Budget review Q4
4. New project proposal discussion
5. Any other business

---

## DISCUSSION SUMMARY

### 1. Previous Action Items Review

| # | Action Item | Owner | Status | Notes |
|---|-------------|-------|--------|-------|
| A1 | Complete vendor evaluation | Suzuki | Done | Selected TechConnect |
| A2 | Submit budget revision | Tanaka | In Progress | Due Jan 25 |
| A3 | Customer feedback analysis | Sato | Done | Report distributed |

### 2. Project Alpha Status

**Current Status:** On Track (Green)

- Phase 2 development: 85% complete
- Testing scheduled: February 1-15
- Go-live target: March 1, 2025

**Issues Raised:**
- Staffing concern: Need 1 additional engineer
- Decision: Approve contractor hiring for 3 months

### 3. Budget Review Q4

| Category | Budget | Actual | Variance |
|----------|--------|--------|----------|
| Personnel | ¥12M | ¥11.5M | +¥0.5M |
| Equipment | ¥5M | ¥4.8M | +¥0.2M |
| Services | ¥3M | ¥3.5M | -¥0.5M |
| **Total** | **¥20M** | **¥19.8M** | **+¥0.2M** |

**Note:** Services over-budget due to unexpected cloud costs. Offset by personnel savings.

### 4. New Project Proposal

**Project Beta:** Customer Portal Redesign
- Proposed by: Sato
- Estimated Budget: ¥8M
- Timeline: April - September 2025
- Decision: Approved for detailed planning phase

### 5. Any Other Business

- Office renovation: Schedule announced for March
- Training: Dify Kanade workshop confirmed for February

---

## ACTION ITEMS

| # | Action | Owner | Due Date |
|---|--------|-------|----------|
| A4 | Submit contractor request | Watanabe | Jan 22 |
| A5 | Finalize budget revision | Tanaka | Jan 25 |
| A6 | Create Project Beta plan | Sato | Feb 5 |
| A7 | Book training room | Yamada | Jan 23 |

---

## NEXT MEETING

**Date:** February 17, 2025
**Time:** 10:00 - 11:30
**Location:** Conference Room A / Teams

---

**Minutes prepared by:** Taro Yamada
**Date:** January 20, 2025
