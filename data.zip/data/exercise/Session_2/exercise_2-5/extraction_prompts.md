# Extraction Prompts for Different Document Types
## For Exercise 2-5

## Invoice Extraction Prompt

```
You are a document processing assistant. Extract the following information from the invoice text.

Document Content:
{{extracted_text}}

Extract and return in JSON format:
{
  "invoice_number": "",
  "invoice_date": "",
  "due_date": "",
  "vendor_name": "",
  "vendor_address": "",
  "customer_name": "",
  "customer_address": "",
  "line_items": [
    {"description": "", "quantity": 0, "unit_price": 0, "amount": 0}
  ],
  "subtotal": 0,
  "tax_amount": 0,
  "total_amount": 0,
  "payment_methods": [],
  "notes": ""
}
```

---

## Contract Extraction Prompt

```
You are a legal document analyst. Extract key contract information from the document.

Document Content:
{{extracted_text}}

Extract and return in JSON format:
{
  "agreement_number": "",
  "agreement_type": "",
  "effective_date": "",
  "expiration_date": "",
  "parties": {
    "provider": {"name": "", "address": "", "representative": ""},
    "customer": {"name": "", "address": "", "representative": ""}
  },
  "services": [
    {"name": "", "description": "", "monthly_fee": 0, "initial_cost": 0}
  ],
  "total_monthly_fee": 0,
  "payment_terms": "",
  "sla_terms": [],
  "termination_conditions": [],
  "auto_renewal": true/false
}
```

---

## Meeting Minutes Extraction Prompt

```
You are a meeting documentation assistant. Extract structured information from the meeting minutes.

Document Content:
{{extracted_text}}

Extract and return in JSON format:
{
  "meeting_title": "",
  "date": "",
  "time": "",
  "location": "",
  "attendees": [
    {"name": "", "department": "", "role": "", "attendance": "in-person/online/absent"}
  ],
  "agenda_items": [],
  "discussion_summary": [
    {"topic": "", "key_points": [], "decisions": []}
  ],
  "action_items": [
    {"action": "", "owner": "", "due_date": "", "status": ""}
  ],
  "next_meeting": {
    "date": "",
    "time": "",
    "location": ""
  }
}
```

---

## Equipment List Extraction Prompt

```
You are an asset management assistant. Extract equipment inventory information from the document.

Document Content:
{{extracted_text}}

Extract and return in JSON format:
{
  "equipment_list": [
    {
      "id": "",
      "name": "",
      "category": "",
      "manufacturer": "",
      "model": "",
      "purchase_date": "",
      "warranty_expiry": "",
      "location": "",
      "status": "",
      "unit_price": 0,
      "assigned_to": ""
    }
  ],
  "summary": {
    "total_items": 0,
    "total_value": 0,
    "by_category": {},
    "by_status": {},
    "expiring_warranties": []
  }
}
```

---

## Generic Document Summary Prompt

```
You are a document summarization assistant. Analyze the document and provide a structured summary.

Document Content:
{{extracted_text}}

Provide analysis in JSON format:
{
  "document_type": "",
  "title": "",
  "date": "",
  "key_parties": [],
  "main_topics": [],
  "summary": "",
  "important_dates": [],
  "monetary_values": [],
  "action_required": []
}
```
